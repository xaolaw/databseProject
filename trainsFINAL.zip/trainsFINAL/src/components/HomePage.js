import React from 'react'
import '../styles/HomePage.css'

export default function HomePage() {
 return (
    <>
    <div className="bgimg">
        <div className="topleft">
            <p>Adam Ćwikła</p>
        </div>
        <div className="middle">
            <h1>Aplikacja do kupowania biletów pociągowych</h1>  
        </div>
    </div>
    </>
  )
}
